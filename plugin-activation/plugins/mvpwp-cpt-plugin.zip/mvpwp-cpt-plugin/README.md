## Custom Post Type Plugin 

Creates a Project custom post type

### Usage 
Install in wp-content/plugins and activate. You will see a Projects custom post type
